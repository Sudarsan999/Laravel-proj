<table id="data_table" class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Reg #</th>
            <th>Category</th>
            <th>Customer</th>
            <th>Vehicle Name</th>
            <th>Plat Number</th>
            <th>Status</th>
            <th>Created At</th>
            <th class="nosort">Operation</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($vehicle->registration_number); ?></td>
            <td><?php echo e($vehicle->category->name); ?></td>
            <td><?php echo e($vehicle->customer->name); ?></td>
            <td><?php echo e($vehicle->name); ?></td>
            <td><?php echo e($vehicle->plat_number); ?></td>
            <td><?php echo e($vehicle->status == 1 ? "Active" : "InActive"); ?></td>
            <td><?php echo e($vehicle->created_at->format('Y/m/d')); ?></td>
            <td>
                <div class="btn-group table-actions">
                    <a href="#" data-toggle="modal" data-target="#show<?php echo e($key); ?>"><i class="ik ik-eye"></i></a>
                    <a href="<?php echo e(route('vehicles.edit', $vehicle->id)); ?>"><i class="ik ik-edit-2"></i></a>
                    <a href="#"  data-toggle="modal" data-target="#delete<?php echo e($key); ?>"><i class="ik ik-trash-2"></i></a>
                </div>
            </td>
            <td></td>
        </tr>
        <?php echo $__env->make('vehicles.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('vehicles.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\adones\Downloads\laravel-car-parking-management\resources\views/vehicles/table.blade.php ENDPATH**/ ?>