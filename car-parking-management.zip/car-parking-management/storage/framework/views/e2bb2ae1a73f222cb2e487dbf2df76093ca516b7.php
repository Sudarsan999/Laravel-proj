<form action="<?php echo e(route('vehicles.store')); ?>" class="forms-sample" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="exampleInputEmail3">Registration Number</label>
                <input type="text" name="registration_number"
                    value="<?php echo e(isset($vehicle) ? $vehicle->registration_number : ''); ?>" class="form-control"
                    id="exampleInputEmail3" readonly placeholder="Registration Number Auto">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="exampleInputName1">Category</label>
                <select name="category_id" class="form-control">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if(isset($vehicle)): ?>
                            <?php echo e($vehicle->category_id == $category->id ? 'selected' : ''); ?>

                    <?php endif; ?>>
                    <?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(isset($vehicle)): ?>
                    <input type="hidden" name="vehicle_id" value="<?php echo e($vehicle->id); ?>">
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="exampleInputName1">Customer Name</label>
                <select name="customer_id" class="form-control">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php if(isset($vehicle)): ?>
                            <?php echo e($vehicle->customer_id == $customer->id ? 'selected' : ''); ?>

                    <?php endif; ?>>
                    <?php echo e($customer->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="exampleInputEmail3">Vehicle Name</label>
                <input type="text" name="name" value="<?php echo e(isset($vehicle) ? $vehicle->name : ''); ?>"
                    class="form-control" id="exampleInputEmail3" placeholder="Vehicle Name">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="exampleInputEmail3">Vehicle Plat Number</label>
                <input type="text" name="plat_number" value="<?php echo e(isset($vehicle) ? $vehicle->plat_number : ''); ?>"
                    class="form-control" id="exampleInputEmail3" placeholder="Vehicle Plat Number">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="exampleInputEmail3">Parking Duration</label>
                <input type="number" name="duration" value="<?php echo e(isset($vehicle) ? $vehicle->duration : ''); ?>"
                    class="form-control" id="exampleInputEmail3" placeholder="Parking Duration">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label for="exampleInputEmail3">Parking Charges</label>
                <input type="number" min="1" name="packing_charge" value="<?php echo e(isset($vehicle) ? $vehicle->packing_charge : ''); ?>"
                    class="form-control" id="exampleInputEmail3" placeholder="Parking Charges">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label for="exampleInputEmail3">Vehicle Status</label>
                <select name="status" class="form-control">
                    <?php $__currentLoopData = getVehicleStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if(isset($vehicle)): ?>
                            <?php echo e($vehicle->status == $key ? 'selected' : ''); ?>

                    <?php endif; ?>>
                    <?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <button type="submit" class="btn btn-primary mr-2">Submit</button>
    <button class="btn btn-light">Cancel</button>
</form>
<?php /**PATH C:\xampp\htdocs\laravel-car-parking-management\resources\views/vehicles/fields.blade.php ENDPATH**/ ?>