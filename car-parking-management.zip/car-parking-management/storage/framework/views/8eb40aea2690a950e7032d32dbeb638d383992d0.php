<form action="<?php echo e(route('customers.store')); ?>" class="forms-sample" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputName1">Name</label>
        <input type="text" name="name" value="<?php echo e(isset($customer) ? $customer->name : ''); ?>" class="form-control" id="exampleInputName1" placeholder="Name">
        <?php if(isset($customer)): ?>
        <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="exampleInputEmail3">Email address</label>
                <input type="email" name="email" value="<?php echo e(isset($customer) ? $customer->email : ''); ?>" class="form-control" id="exampleInputEmail3" placeholder="Email">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="exampleInputEmail3">Phone</label>
                <input type="tel" name="phone" value="<?php echo e(isset($customer) ? $customer->phone : ''); ?>" class="form-control" id="exampleInputEmail3" placeholder="Phone">
            </div>
        </div>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword4">Company</label>
        <input type="text" name="company" value="<?php echo e(isset($customer) ? $customer->company : ''); ?>" class="form-control" id="exampleInputPassword4" placeholder="Company">
    </div>

    <div class="form-group">
        <label for="exampleTextarea1">Address</label>
        <textarea class="form-control" name="address" id="exampleTextarea1" rows="4"><?php echo e(isset($customer) ? $customer->address : ''); ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary mr-2">Submit</button>
    <button class="btn btn-light">Cancel</button>
</form>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/customers/fields.blade.php ENDPATH**/ ?>