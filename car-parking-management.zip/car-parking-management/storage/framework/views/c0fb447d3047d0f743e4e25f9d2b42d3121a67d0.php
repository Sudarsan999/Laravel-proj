<?php if(Session::has('error')): ?>
<div class="alert alert-danger">
  <?php echo e(Session::get('error')); ?>

</div>
<?php elseif(Session::has('success')): ?>
<div class="alert alert-success">
    <?php echo e(Session::get('success')); ?>

  </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/flash.blade.php ENDPATH**/ ?>