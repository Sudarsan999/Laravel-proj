<table id="data_table" class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Reg #</th>
            <th>Vehicle Name</th>
            <th>Parking Area</th>
            <th>Parking Number</th>
            <th>Created At</th>
            <th>Created By</th>
            <th class="nosort">Operation</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehicleOut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($vehicleOut->vehicleIn->vehicle->registration_number); ?></td>
            <td><?php echo e($vehicleOut->vehicleIn->vehicle->name); ?></td>
            <td><?php echo e($vehicleOut->vehicleIn->parking_area); ?></td>
            <td><?php echo e($vehicleOut->vehicleIn->parking_number); ?></td>
            <td><?php echo e($vehicleOut->created_at->format('Y/m/d H:i A')); ?></td>
            <td><?php echo e($vehicleOut->user->name); ?></td>
            <td>
                <div class="table-actions">
                    <a href="#"><i class="ik ik-printer"></i></a>
                    
                </div>
            </td>
            <td></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="12" class="text-center"> No data Found</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/reports/table_out.blade.php ENDPATH**/ ?>