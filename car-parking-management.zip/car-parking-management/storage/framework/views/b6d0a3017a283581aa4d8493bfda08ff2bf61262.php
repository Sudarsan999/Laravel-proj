<!-- resources/views/profile/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Welcome, <?php echo e($user->name); ?>!</h1>
        <p>Email: <?php echo e($user->email); ?></p>
        <!-- Add other profile information as needed -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/profile/show.blade.php ENDPATH**/ ?>