  <!-- Modal -->
  <div class="modal fade" id="delete<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($user->name); ?> </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
                <form id="delete-data" action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST" class="d-none">
                    <?php echo method_field('Delete'); ?>
                    <?php echo csrf_field(); ?>
                    <label for="" class="text-center">Are you sure you want to delete this?</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger">Yes Delete</button>
        </div>
    </form>
      </div>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/admins/delete.blade.php ENDPATH**/ ?>