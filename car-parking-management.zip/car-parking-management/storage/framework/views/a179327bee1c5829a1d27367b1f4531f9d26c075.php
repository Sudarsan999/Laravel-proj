<form action="<?php echo e(route('categories.store')); ?>" class="forms-sample" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputName1">Name</label>
        <input type="text" name="name" value="<?php echo e(isset($category) ? $category->name : ''); ?>" class="form-control" id="exampleInputName1" placeholder="Name">
        <?php if(isset($category)): ?>
        <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
        <?php endif; ?>
    </div>
    <button type="submit" class="btn btn-primary mr-2">Submit</button>
    <button class="btn btn-light">Cancel</button>
</form>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/categories/fields.blade.php ENDPATH**/ ?>