<div class="app-sidebar colored">
    <div class="sidebar-header">
        <a class="header-brand" href="index.html">
            <div class="logo-img">
                JSS
               
            </div>
            <span class="text">&nbsp; Parking Sys</span>
        </a>
        <button type="button" class="nav-toggle"><i data-toggle="expanded" class="ik ik-toggle-right toggle-icon"></i></button>
        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
    </div>

    <div class="sidebar-content">
        <div class="nav-container">
            <nav id="main-menu-navigation" class="navigation-main">
                <div class="nav-lavel">Navigation</div>
                <div class="nav-item active">
                    <a href="<?php echo e(route('home')); ?>"><i class="ik ik-bar-chart-2"></i><span>Dashboard</span></a>
                </div>

                <div class="nav-item has-sub <?php echo e(request()->routeIs('user*')  ? 'open' : ''); ?>">
                    <a href="javascript:void(0)"><i class="ik ik-user"></i><span>Manage Admins </span> </a>
                    <div class="submenu-content">
                        <a href="<?php echo e(route('user.create')); ?>" class="menu-item <?php echo e(request()->routeIs('user.create') ? 'active' : ''); ?>">Create</a>
                        <a href="<?php echo e(route('user.index')); ?>" class="menu-item  <?php echo e(request()->routeIs('user.index') ? 'active' : ''); ?>">List</a>
                    </div>
                </div>
                <div class="nav-item has-sub <?php echo e(request()->routeIs('customers*')  ? 'open' : ''); ?>">
                    <a href="javascript:void(0)"><i class="ik ik-users"></i><span>Manage Customers </span> </a>
                    <div class="submenu-content">
                        <a href="<?php echo e(route('customers.create')); ?>" class="menu-item  <?php echo e(request()->routeIs('customers.create') ? 'active' : ''); ?>">Create</a>
                        <a href="<?php echo e(route('customers.index')); ?>" class="menu-item  <?php echo e(request()->routeIs('customers.index') ? 'active' : ''); ?>">List</a>
                    </div>
                </div>
                <div class="nav-lavel">UI Element</div>
                <div class="nav-item has-sub <?php echo e(request()->routeIs('categories*')  ? 'open' : ''); ?>">
                    <a href="#"><i class="ik ik-box"></i><span>Manage Category</span></a>
                    <div class="submenu-content">
                        <a href="<?php echo e(route('categories.create')); ?>" class="menu-item  <?php echo e(request()->routeIs('categories.create') ? 'active' : ''); ?>">Create</a>
                        <a href="<?php echo e(route('categories.index')); ?>" class="menu-item  <?php echo e(request()->routeIs('categories.index') ? 'active' : ''); ?>">List</a>
                    </div>
                </div>
                <div class="nav-item has-sub <?php echo e(request()->routeIs('vehicles*')  ? 'open' : ''); ?>">
                    <a href="#"><i class="ik ik-truck"></i><span>Register Vehicles</span> </a>
                    <div class="submenu-content">
                        <a href="<?php echo e(route('vehicles.create')); ?>" class="menu-item  <?php echo e(request()->routeIs('vehicles.create') ? 'active' : ''); ?>">Create</a>
                        <a href="<?php echo e(route('vehicles.index')); ?>" class="menu-item  <?php echo e(request()->routeIs('vehicles.index') ? 'active' : ''); ?>">List</a>
                    </div>
                </div>

                <div class="nav-item has-sub <?php echo e(request()->routeIs('vehiclesIn*') || request()->routeIs('vehiclesOut*')  ? 'open' : ''); ?>">
                    <a href="#"><i class="ik ik-gitlab"></i><span>Manage Vehicles</span> </a>
                    <div class="submenu-content">
                        <a href="<?php echo e(route('vehiclesIn.index')); ?>" class="menu-item  <?php echo e(request()->routeIs('vehiclesIn*') ? 'active' : ''); ?>">In Vehicles</a>
                        <a href="<?php echo e(route('vehiclesOut.index')); ?>" class="menu-item  <?php echo e(request()->routeIs('vehiclesOut*') ? 'active' : ''); ?>">Out Vehicle</a>
                    </div>
                </div>

                <div class="nav-lavel">Reports Section</div>
                <div class="nav-item has-sub">
                    <a href="<?php echo e(route('reports.index')); ?>"><i class="ik ik-edit"></i><span>Report</span></a>
                    
                </div>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\adones\Downloads\laravel-car-parking-management-main\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>