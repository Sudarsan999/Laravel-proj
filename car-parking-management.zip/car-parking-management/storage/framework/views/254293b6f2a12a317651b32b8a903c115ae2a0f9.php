<table id="data_table" class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Reg #</th>
            <th>Vehicle Name</th>
            <th>Parking Area</th>
            <th>Parking Number</th>
            <th>Created At</th>
            <th>Created By</th>
            <th class="nosort">Operation</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehicleIn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($vehicleIn->vehicle->registration_number); ?></td>
            <td><?php echo e($vehicleIn->vehicle->name); ?></td>
            <td><?php echo e($vehicleIn->parking_area); ?></td>
            <td><?php echo e($vehicleIn->parking_number); ?></td>
            <td><?php echo e($vehicleIn->created_at->format('Y/m/d H:i A')); ?></td>
            <td><?php echo e($vehicleIn->user->name); ?></td>
            <td>
                <div class="table-actions">
                    <a href="#"><i class="ik ik-print"></i></a>
                    <a href="<?php echo e(route('vehiclesIn.edit', $vehicleIn->id)); ?>"><i class="ik ik-edit-2"></i></a>
                    <a href="#" onclick=" confirm('Are you sure you want to delete this?');
                    document.getElementById('delete-data').submit();"><i class="ik ik-trash-2"></i></a>

                     <form id="delete-data" action="<?php echo e(route('vehiclesIn.destroy', $vehicleIn->id)); ?>" method="POST" class="d-none">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </td>
            <td></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/reports/table_in.blade.php ENDPATH**/ ?>