<form action="<?php echo e(route('vehiclesIn.store')); ?>" class="forms-sample" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="exampleInputName1">Select Vehicle</label>
                <select name="vehicle_id" class="form-control">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehicle->id); ?>" <?php if(isset($vehiclesIn)): ?>
                            <?php echo e($vehiclesIn->vehicle_id == $vehicle->id ? 'selected' : ''); ?>

                    <?php endif; ?>>
                    <?php echo e($vehicle->name .' - '. $vehicle->registration_number); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(isset($vehiclesIn)): ?>
                    <input type="hidden" name="vehiclesIn_id" value="<?php echo e($vehiclesIn->id); ?>">
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
            <label for="exampleInputName1">Select Parking Area</label>
            <select name="parking_area" class="form-control">
                <?php $__currentLoopData = getParkingareas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parking_area); ?>" <?php if(isset($vehiclesIn)): ?>
                        <?php echo e($vehiclesIn->parking_area == $parking_area ? 'selected' : ''); ?>

                <?php endif; ?>>
                <?php echo e($parking_area); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="exampleInputEmail3">Parking Number</label>
                <input type="text" name="parking_number" value="<?php echo e(isset($vehiclesIn) ? $vehiclesIn->parking_number : ''); ?>"
                    class="form-control" id="exampleInputEmail3" placeholder="Parking Number">
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary mr-2">Submit</button>
    <button class="btn btn-light">Cancel</button>
</form>
<?php /**PATH C:\xampp\htdocs\laravel-car-parking-management\resources\views/vehicles_in/fields.blade.php ENDPATH**/ ?>