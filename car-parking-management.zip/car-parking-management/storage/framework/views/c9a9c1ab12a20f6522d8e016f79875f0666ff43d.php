<table id="data_table" class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Created By</th>
            <th>Created At</th>
            <th class="nosort">Operation</th>
            <td>Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->user->name); ?></td>
            <td><?php echo e($category->created_at->format('Y/m/d')); ?></td>
            <td>
                <div class="table-actions">
                    
                    <a href="<?php echo e(route('categories.edit', $category->cat_id)); ?>"><i class="ik ik-edit-2"></i></a>
                    <a href="#" data-toggle="modal" data-target="#delete<?php echo e($key); ?>"><i class="ik ik-trash-2"></i></a>
                </div>
            </td>
            <td></td>
        </tr>
        <?php echo $__env->make('categories.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\laravel-car-parking-management\resources\views/categories/table.blade.php ENDPATH**/ ?>