<form action="<?php echo e(route('vehiclesOut.store')); ?>" class="forms-sample" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="exampleInputName1">Select Vehicle</label>
                <select name="vehicleIn_id" class="form-control">
                <option value="">Select</option>
                    <?php $__currentLoopData = $vehiclesIn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleIn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehicleIn->id); ?>" <?php if(isset($vehiclesOut)): ?>
                            <?php echo e($vehiclesOut->vehicle_id == $vehicleIn->vehicle->id ? 'selected' : ''); ?>

                    <?php endif; ?>>
                    <?php echo e($vehicleIn->vehicle->name .' - '. $vehicleIn->vehicle->registration_number); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(isset($vehiclesOut)): ?>
                    <input type="hidden" name="vehiclesOut_id" value="<?php echo e($vehiclesOut->id); ?>">
                <?php endif; ?>
            </div>
        </div>
        
    </div>

    <button type="submit" class="btn btn-primary mr-2">Submit</button>
    <button class="btn btn-light">Cancel</button>
</form>
<?php /**PATH C:\xampp\htdocs\car-parking-management\resources\views/vehicles_out/fields.blade.php ENDPATH**/ ?>