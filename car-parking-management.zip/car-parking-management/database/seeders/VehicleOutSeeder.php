<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class VehicleOutSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
